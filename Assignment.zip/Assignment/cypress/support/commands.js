// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })

import pageobject from '../PageObjects/Objects'

Cypress.Commands.add('Login', (username, password)  => {
 cy.get(pageobject.Emaillogin).type(username)
 cy.get(pageobject.Passwordlogin).type(password)
 cy.get(pageobject.LoginButton).click()

} )

Cypress.Commands.add('CreateAccount', (firstname, lastname, emailaddress, password) => {

cy.get(pageobject.FirstName).type(firstname)
cy.get(pageobject.LastName).type(lastname)
cy.get(pageobject.Email).type(emailaddress)
cy.get(pageobject.Password).type(password)

})
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })

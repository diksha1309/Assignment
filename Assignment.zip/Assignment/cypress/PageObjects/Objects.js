export default{

//Let's Get Started 

New: '[data-cy="new"]',
Existing: '[data-cy="existing"]',

// Where is your company based?

Province: '[data-cy="province"]',
Provincemenu: '[data-cy="province-menu"]',
Nextone: '[data-cy="next"]',

//Choose your business structure
Incorporation: '[data-cy="incorporation"]',
Sole: '[data-cy="soleProp"]',

//Start a Corporation
Namedornumbered: '[data-cy="namedOrNumbered"]',
Name: '[data-cy="companyNameInput"]',
Confirmed: '[data-cy="success"]',
Nexttwo: '[data-cy="submit"]',

//Start a Sole Proprietorship
Namesole: '[data-cy="companyNameInput"]',


//Create your account
FirstName: '[data-cy="firstName"]',
LastName: '[data-cy="lastName"]',
Email: '[data-cy="email"]',
Password: '[data-cy="password"]',
Lengthrule: '[data-cy="lengthRule"]',
Letterrule: '[data-cy="letterRule"]',
Numberrule: '[data-cy="numberRule"]',
PasswordConfirm: '[aria-live="assertive"]',
SignUp: '[data-cy="submit"]',
Error: '[data-cy="error-message"]',

//Login

Emaillogin: '[data-cy="email"]',
Passwordlogin: '[data-cy="password"]',
LoginButton: '[data-cy="login"]',



//Account Information

PageTitle: '[data-cy="page-title"]',
Phone: '[data-cy="phone-number"]',
Streetaddress1: '[placeholder="10 Dundas St."]',
Streetaddress2: '[placeholder="Unit 101"]',
City: '[placeholder="Toronto"]',
PostalCode: '[placeholder="A1A 1A1"]',
Checkbox: '[data-cy="checkbox-canadian-resident"]',
Nextthree: '[data-cy="next"]',
Profile: '[data-cy="nav-profile"]',
Signout: '[data-cy="sign-out"]'



}
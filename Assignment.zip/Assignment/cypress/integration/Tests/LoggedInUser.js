/// <reference types="cypress" />

import loggedinobject from '../../PageObjects/Objects'

describe('Loggedin User', function(){

beforeEach(() => {
        // Since we want to visit the same URL at the start of all our tests,
        // we include it in our beforeEach function so that it runs before each test
        cy.visit('https://www.ownr.co/login')
                })

// Login Functionality

it('Validate Login functionality',function(){  
    
   cy.Login('dikshasharma@gmail.com','Dikshajain@13')  //Custom command "Login" is used
   
    })


// Validate Account Information screen

it('Account Information',function(){  
    
    cy.Login('dikshasharma@gmail.com','Dikshajain@13') //Custom command "Login" is used
    cy.get(loggedinobject.Phone).type('647-267-0000')
    cy.get(loggedinobject.Streetaddress1).type('5 Lanercost Way')
    cy.get(loggedinobject.City).type('Brampton')
    cy.get(loggedinobject.PostalCode).type('L6Z 4J5')
    cy.get(loggedinobject.Checkbox).should('not.be.checked')
    cy.get(loggedinobject.Nextthree).click()

}) 

afterEach ( () => {

// Sign out after each test
  cy.get(loggedinobject.Profile).click()
  cy.get(loggedinobject.Signout).click()

})

})
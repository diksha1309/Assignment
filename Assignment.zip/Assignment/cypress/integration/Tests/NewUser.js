/// <reference types="cypress" />

import object from '../../PageObjects/Objects'

describe('Onboarding Flow', function()
{

beforeEach(() => {
        // Since we want to visit the same URL at the start of all our tests,
        // we include it in our beforeEach function so that it runs before each test
        cy.visit('https://www.ownr.co/new')
                 })

// Validating options present for the user when visiting the website

it('Validate New and Existing options are present',function(){  
    
    cy.get(object.New).should('have.text', 'New')
    cy.get(object.Existing).should('have.text', 'Existing')

})

// Sign Up flow of a New incorporation business 
   
it('Validate Sign up for a new incorporation business',function(){

    cy.get(object.New).click()
    cy.get(object.Province).should('contain','Ontario')
    cy.get(object.Nextone).click()
    cy.get(object.Incorporation).click()
    cy.get(object.Namedornumbered).should('contain','Named')
    cy.get(object.Name).type('Diksha Jain Company')
    cy.get(object.Confirmed).should('contain', 'Confirmed')
    cy.get(object.Nexttwo).click()
    cy.CreateAccount('Diksha','Jain','abghijkl@gmail.com','Dikshajain@13')   //Custom command "CreateAccount" is used
    cy.get(object.PasswordConfirm).should('have.text',"Your password is secure and you're all set!")
    cy.get(object.SignUp).click()
    cy.get(object.PageTitle).should('contain', 'Account Information')

})

// Sign Up flow of a New sole proprietorship

it('Validate Sign up for a new sole proprietorship',function(){  

    cy.get(object.New).click()
    cy.get(object.Province).should('contain','Ontario')
    cy.get(object.Nextone).click()
    cy.get(object.Sole).click()
    cy.get(object.Namesole).type('Diksha Jain Company')
    cy.get(object.Confirmed).should('contain', 'Confirmed')
    cy.get(object.Nexttwo).click()
    cy.CreateAccount('Diksha','Jain','uvwx1099@gmail.com','Dikshajain@13')  //Custom command "CreateAccount" is used
    cy.get(object.PasswordConfirm).should('have.text',"Your password is secure and you're all set!")
    cy.get(object.SignUp).click()
    cy.get(object.PageTitle).should('contain', 'Account Information')
    
    
})

// Sign Up using an existing email address

it('Validate error for sign up using an existing email address',function(){   
    
    
    cy.get(object.New).click()   
    cy.get(object.Nextone).click()
    cy.get(object.Incorporation).click()
    cy.get(object.Name).type('D Company')
    cy.get(object.Confirmed).should('contain', 'Confirmed')
    cy.get(object.Nexttwo).click()
    cy.CreateAccount('Diksha','Jain','dj@gmail.com','Dikshajain@13')
    cy.get(object.SignUp).click()
    cy.get(object.Error).should('contain','There was a problem creating your account or that email address may already be in use.')        
        
})

})
